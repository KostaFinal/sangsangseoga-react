export const steps = [
  { key: "seed", label: "이야기 씨앗" },
  { key: "pageCount", label: "페이지 수" },
  { key: "character", label: "주인공" },
  { key: "setting", label: "배경" },
  { key: "event", label: "사건" },
  { key: "mood", label: "분위기" },
  { key: "lesson", label: "교훈" },
];

export const seedOptions = [
  {
    id: "MAGIC_OBJECT",
    icon: "1",
    title: "마법 물건 이야기",
  },
  {
    id: "FRIENDSHIP",
    icon: "2",
    title: "친구와 함께하는 이야기",
  },
  {
    id: "COURAGE",
    icon: "3",
    title: "작은 용기를 내는 이야기",
  },
  {
    id: "FOREST",
    icon: "4",
    title: "신비한 숲 모험",
  },
  {
    id: "CUSTOM",
    icon: "+",
    title: "직접 입력하기",
  },
];

export const pageCountOptions = [
  {
    id: "PAGE_10",
    value: 10,
    icon: "1",
    title: "10쪽",
    description: "짧고 빠르게 완성하는 동화",
  },
  {
    id: "PAGE_12",
    value: 12,
    icon: "2",
    title: "12쪽",
    description: "기승전결이 간단히 들어가는 기본 동화",
  },
  {
    id: "PAGE_16",
    value: 16,
    icon: "3",
    title: "16쪽",
    description: "사건과 감정 변화를 조금 더 자세히 담는 동화",
  },
  {
    id: "PAGE_20",
    value: 20,
    icon: "4",
    title: "20쪽",
    description: "가장 풍성하게 만드는 긴 동화",
  },
];

export const initialSettings = {
  seed: "마법 물건 이야기",
  pageCount: 12,
  character: "",
  setting: "",
  event: "",
  mood: "",
  lesson: "",
};
