import * as BookCreationRouterModule from './components/BookCreationRouter.jsx';

export const BookCreationRouter =
  BookCreationRouterModule.BookCreationRouter || BookCreationRouterModule.default;

export { PoemCreationView } from './poem';
export { EssayCreationView } from './essay';
