import React from "react";

export default function PoemSettingRow({
  label,
  helper,
  options,
  required = false,
  value,
  onPick,
  showAiRecommend = false,
  onAiRecommend,
}) {
  return (
    <div className="setting-row">
      <div>
        <strong>
          {label}
          <em>{required ? "필수" : "선택"}</em>
        </strong>
        <span>{helper}</span>
      </div>

      <div className={showAiRecommend ? "keyword-option-control" : ""}>
        <div className="option-button-grid">
          {options.map((option) => (
            <button
              type="button"
              key={option}
              data-long={option.length >= 6 ? "true" : undefined}
              className={value === option ? "selected" : ""}
              onClick={() => onPick(option)}
            >
              {option}
            </button>
          ))}

          {showAiRecommend && (
            <button
              type="button"
              className="ai-recommend-option"
              onClick={onAiRecommend}
            >
              AI 추천
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
