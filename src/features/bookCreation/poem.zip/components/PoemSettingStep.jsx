import React from "react";
import PoemFlowStepper from "./PoemFlowStepper.jsx";
import PoemSettingRow from "./PoemSettingRow.jsx";
import { basicOptions, getBasicRecommendation } from "../poemShared.js";

export default function PoemSettingStep({
  settings,
  setSettings,
  setCurrentView,
  requestViewChange,
}) {
  const commonRows = [
    [
      "authorAge",
      "작가 연령대",
      "시를 쓰는 사람의 연령대를 골라주세요.",
      basicOptions.authorAge,
      true,
    ],
    [
      "readerAge",
      "독자 연령대",
      "시를 읽을 사람의 연령대를 골라주세요.",
      basicOptions.readerAge,
      false,
    ],
  ];

  const guidedRows = [
    [
      "topic",
      "주제",
      "시에서 가장 중심이 되는 단어예요.",
      basicOptions.topic,
      true,
    ],
    ["style", "형식", "시의 기본 모양을 정해요.", basicOptions.style, true],
    [
      "length",
      "길이",
      "시가 어느 정도 분량이면 좋을지 정해요.",
      basicOptions.length,
      true,
    ],
    [
      "mood",
      "분위기",
      "원하는 경우 시의 온도와 색깔을 더해요.",
      basicOptions.mood,
      false,
    ],
  ];

  const rows =
    settings.mode === "free" ? commonRows : [...commonRows, ...guidedRows];

  const isFilled = (value) => String(value || "").trim().length > 0;

  const canGoNext = rows.every(
    ([key, , , , required]) => !required || isFilled(settings[key]),
  );

  const pickOption = (key, option, required) => {
    setSettings((prev) => ({
      ...prev,
      [key]: prev[key] === option && !required ? "" : option,
    }));
  };

  const applyAiRecommendation = (key) => {
    const recommendation = getBasicRecommendation(key, settings);
    if (!recommendation) return;

    setSettings((prev) => ({
      ...prev,
      [key]: recommendation,
    }));
  };

  return (
    <section className="step-page compact-page">
      <PoemFlowStepper active={2} />

      <div className="basic-form-card">
        <div className="settings-group visual-settings">
          {rows.map(([key, label, helper, options, required]) => (
            <PoemSettingRow
              key={key}
              label={label}
              helper={helper}
              options={options}
              required={required}
              value={settings[key]}
              onPick={(option) => pickOption(key, option, required)}
              showAiRecommend={["topic", "mood"].includes(key)}
              onAiRecommend={() => applyAiRecommendation(key)}
            />
          ))}
        </div>
      </div>

      <div className="bottom-actions">
        <button
          type="button"
          className="ghost"
          onClick={() => setCurrentView("step1")}
        >
          이전
        </button>

        <button
          type="button"
          className="primary"
          disabled={!canGoNext}
          onClick={() => setCurrentView("step3")}
        >
          다음
        </button>
      </div>
    </section>
  );
}
